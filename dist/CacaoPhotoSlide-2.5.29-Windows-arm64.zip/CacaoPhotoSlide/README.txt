CacaoPhotoSlide 2.5.29（Windows 版・arm64: ARM 版 Windows 用（Mac の仮想マシンなど））

CacaoPhotoSlide.exe をダブルクリックで起動します（インストール不要）。
Windows 10 / 11。WebView2 が必要です（Windows 11 と、更新された Windows 10 には入っています）。

最初に開くとき SmartScreen の警告が出たら「詳細情報」→「実行」を押してください（署名していないため）。
mp4 に書き出すときは ffmpeg を使います。初めての書き出しのとき、自動で GitHub から取ってきます（数十 MB）。

写真のフォルダを窓にドロップするとスライドショーになります。書類（.cpsd）は Mac 版と同じ形式です。
https://github.com/ICTCacao/CacaoPhotoSlide
